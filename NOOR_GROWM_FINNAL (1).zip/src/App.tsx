import React, { useState } from 'react';
import { SiteHeader } from './components/layout/SiteHeader';
import { SiteFooter } from './components/layout/SiteFooter';
import { HomeHeroNoorStyle } from './components/sections/HomeHeroNoorStyle';
import { ProductCard } from './components/commerce/ProductCard';
import { CollectionPage } from './components/pages/CollectionPage';
import { ProductDetailPage } from './components/pages/ProductDetailPage';
import { CustomerDashboard } from './components/pages/CustomerDashboard';
import { ArrowRight } from 'lucide-react';
import { useScreenInit } from './useScreenInit';
export function App() {
  const screenInit = useScreenInit();
  const [currentView, setCurrentView] = useState<
    'home' | 'collection' | 'pdp' | 'profile'>(
    screenInit?.currentView || 'home');
  const products = [
  {
    title: 'Prémiový Kolagén Komplex',
    price: 'Od 47,95 €',
    image:
    'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?q=80&w=800&auto=format&fit=crop',
    hoverImage:
    'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?q=80&w=800&auto=format&fit=crop',
    badge: 'Najpredávanejšie'
  },
  {
    title: 'Lipozomálny Vitamín C',
    price: 'Od 64,95 €',
    image:
    'https://images.unsplash.com/photo-1608248543803-ba4f8c70ae0b?q=80&w=800&auto=format&fit=crop',
    hoverImage:
    'https://images.unsplash.com/photo-1617897903246-719242758050?q=80&w=800&auto=format&fit=crop'
  },
  {
    title: 'Horčík Bisglycinát',
    price: 'Od 52,95 €',
    image:
    'https://images.unsplash.com/photo-1629198688000-71f23e745b6e?q=80&w=800&auto=format&fit=crop',
    hoverImage:
    'https://images.unsplash.com/photo-1550831107-1553da8c8464?q=80&w=800&auto=format&fit=crop',
    badge: 'Novinka'
  },
  {
    title: 'Omega-3 Premium',
    price: 'Od 38,95 €',
    image:
    'https://images.unsplash.com/photo-1556228720-192a6af4e865?q=80&w=800&auto=format&fit=crop',
    hoverImage:
    'https://images.unsplash.com/photo-1570194065650-d6a2b8e30f14?q=80&w=800&auto=format&fit=crop'
  }];

  // Simple wrapper to handle clicks on product cards or links for preview purposes
  const handleNavigation =
  (view: 'home' | 'collection' | 'pdp' | 'profile') =>
  (e: React.MouseEvent) => {
    e.preventDefault();
    setCurrentView(view);
    window.scrollTo(0, 0);
  };
  return (
    <div className="min-h-screen bg-gm-bg flex flex-col font-body">
      <SiteHeader />

      {/* Dev Navigation Bar - Just for preview purposes to switch views easily */}
      <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-[100] bg-black/80 backdrop-blur-md text-white px-6 py-3 rounded-full flex space-x-4 text-sm font-medium shadow-2xl">
        <button
          onClick={() => {
            setCurrentView('home');
            window.scrollTo(0, 0);
          }}
          className={
          currentView === 'home' ? 'text-gm-primary' : 'hover:text-gm-primary'
          }>
          
          Domov
        </button>
        <button
          onClick={() => {
            setCurrentView('collection');
            window.scrollTo(0, 0);
          }}
          className={
          currentView === 'collection' ?
          'text-gm-primary' :
          'hover:text-gm-primary'
          }>
          
          Kolekcia
        </button>
        <button
          onClick={() => {
            setCurrentView('pdp');
            window.scrollTo(0, 0);
          }}
          className={
          currentView === 'pdp' ? 'text-gm-primary' : 'hover:text-gm-primary'
          }>
          
          Detail produktu
        </button>
        <button
          onClick={() => {
            setCurrentView('profile');
            window.scrollTo(0, 0);
          }}
          className={
          currentView === 'profile' ?
          'text-gm-primary' :
          'hover:text-gm-primary'
          }>
          
          Profil
        </button>
      </div>

      <main className="flex-grow">
        {currentView === 'home' &&
        <>
            <HomeHeroNoorStyle />

            {/* Featured Collection Section */}
            <section className="py-24">
              <div className="gm-container">
                <div className="flex flex-col md:flex-row md:items-end justify-between mb-12">
                  <div className="max-w-2xl">
                    <h2 className="text-3xl md:text-4xl font-heading text-gm-text mb-4">
                      Naše{' '}
                      <span className="italic font-light">Bestsellery</span>
                    </h2>
                    <p className="text-gm-text-muted text-lg">
                      Objavte naše najobľúbenejšie prémiové doplnky výživy pre
                      vaše každodenné zdravie a vitalitu.
                    </p>
                  </div>
                  <a
                  href="#"
                  onClick={handleNavigation('collection')}
                  className="hidden md:inline-flex items-center text-gm-primary font-medium hover:text-gm-primary-hover transition-colors">
                  
                    Zobraziť všetko <ArrowRight className="ml-2 w-4 h-4" />
                  </a>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                  {products.map((product, idx) =>
                <div key={idx} onClick={handleNavigation('pdp')}>
                      <ProductCard {...product} />
                    </div>
                )}
                </div>

                <div className="mt-8 text-center md:hidden">
                  <a
                  href="#"
                  onClick={handleNavigation('collection')}
                  className="inline-flex items-center text-gm-primary font-medium hover:text-gm-primary-hover transition-colors">
                  
                    Zobraziť všetko <ArrowRight className="ml-2 w-4 h-4" />
                  </a>
                </div>
              </div>
            </section>

            {/* Editorial Section */}
            <section className="py-12 md:py-24 bg-gm-bg-soft">
              <div className="gm-container">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
                  <div className="order-2 md:order-1">
                    <h2 className="text-3xl md:text-5xl font-heading text-gm-text mb-6 leading-tight">
                      Zdravie začína zvnútra s našimi{' '}
                      <span className="italic font-light">
                        Prémiovými doplnkami
                      </span>
                    </h2>
                    <p className="text-gm-text-muted text-lg mb-8 leading-relaxed">
                      Podporte svoju prirodzenú vitalitu s našou starostlivo
                      vybranou kolekciou doplnkov výživy. Plné čistých
                      ingrediencií a vedecky overených receptúr, každý produkt
                      pracuje v harmónii s vaším telom pre lepšiu imunitu,
                      energiu a celkové zdravie.
                    </p>
                    <button className="inline-flex items-center justify-center px-8 py-3.5 rounded-full border border-gm-text text-gm-text hover:bg-gm-text hover:text-white transition-all duration-300">
                      <ArrowRight className="mr-2 w-4 h-4" /> Preskúmať
                    </button>
                  </div>
                  <div className="order-1 md:order-2">
                    <div className="aspect-[4/3] md:aspect-square rounded-gm-lg overflow-hidden">
                      <img
                      src="https://images.unsplash.com/photo-1515377905703-c4788e51af15?q=80&w=1000&auto=format&fit=crop"
                      alt="Natural Beauty"
                      className="w-full h-full object-cover" />
                    
                    </div>
                  </div>
                </div>
              </div>
            </section>
          </>
        }

        {currentView === 'collection' && <CollectionPage />}
        {currentView === 'pdp' && <ProductDetailPage />}
        {currentView === 'profile' && <CustomerDashboard />}
      </main>

      <SiteFooter />
    </div>);

}