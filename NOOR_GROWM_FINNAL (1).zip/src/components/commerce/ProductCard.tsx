import React from 'react';
import { ArrowRight } from 'lucide-react';
interface ProductCardProps {
  title: string;
  price: string;
  image: string;
  hoverImage?: string;
  badge?: string;
}
export const ProductCard = ({
  title,
  price,
  image,
  hoverImage,
  badge
}: ProductCardProps) => {
  return (
    <div className="group cursor-pointer flex flex-col">
      <div className="relative aspect-[3/4] bg-gm-bg-soft rounded-gm-md overflow-hidden mb-4">
        {badge &&
        <div className="absolute top-3 left-3 z-10 bg-white/90 backdrop-blur-sm px-3 py-1 text-xs font-medium tracking-wide rounded-full text-gm-text">
            {badge}
          </div>
        }

        <img
          src={image}
          alt={title}
          className="absolute inset-0 w-full h-full object-cover object-center transition-opacity duration-500 ease-in-out group-hover:opacity-0" />
        

        {hoverImage &&
        <img
          src={hoverImage}
          alt={`${title} alternate view`}
          className="absolute inset-0 w-full h-full object-cover object-center opacity-0 transition-opacity duration-500 ease-in-out group-hover:opacity-100" />

        }

        {/* Quick Add Button Overlay */}
        <div className="absolute inset-x-4 bottom-4 translate-y-4 opacity-0 transition-all duration-300 ease-out group-hover:translate-y-0 group-hover:opacity-100 flex justify-center">
          <button className="bg-white/95 backdrop-blur-md text-gm-text font-medium text-sm px-6 py-3 rounded-full shadow-lg hover:bg-gm-primary hover:text-white transition-colors w-full flex items-center justify-center">
            Do košíka
          </button>
        </div>
      </div>

      <div className="flex flex-col items-center text-center px-2">
        <h3 className="font-heading text-lg text-gm-text mb-1 group-hover:text-gm-primary transition-colors">
          {title}
        </h3>
        <p className="text-gm-text-muted text-sm">{price}</p>
      </div>
    </div>);

};