import React from 'react';
import { clsx } from 'clsx';
import { ArrowRight } from 'lucide-react';
interface MegaMenuProps {
  isOpen: boolean;
  onClose: () => void;
}
export const MegaMenu = ({ isOpen, onClose }: MegaMenuProps) => {
  if (!isOpen) return null;
  const categories = [
  {
    title: 'Imunita a Zdravie',
    image:
    'https://images.unsplash.com/photo-1617897903246-719242758050?q=80&w=800&auto=format&fit=crop',
    links: ['Vitamín C', 'Zinok', 'Probiotiká', 'Multivitamíny']
  },
  {
    title: 'Krása a Vitalita',
    image:
    'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?q=80&w=800&auto=format&fit=crop',
    links: [
    'Kolagén',
    'Kyselina hyalurónová',
    'Vlasy a nechty',
    'Antioxidanty']

  },
  {
    title: 'Energia a Spánok',
    image:
    'https://images.unsplash.com/photo-1550831107-1553da8c8464?q=80&w=800&auto=format&fit=crop',
    links: ['Horčík', 'Melatonín', 'B-Komplex', 'Adaptogény']
  }];

  return (
    <div
      className="absolute top-full left-0 w-full bg-gm-surface shadow-gm-soft border-t border-gm-border overflow-hidden transition-all duration-300 ease-in-out origin-top"
      onMouseLeave={onClose}>
      
      <div className="gm-container py-12">
        <div className="grid grid-cols-4 gap-8">
          <div className="col-span-1">
            <h3 className="text-xl font-heading mb-6 text-gm-text">
              Nakupovať podľa
            </h3>
            <ul className="space-y-4">
              <li>
                <a
                  href="#"
                  className="text-gm-text-muted hover:text-gm-primary transition-colors">
                  
                  Všetky produkty
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-gm-text-muted hover:text-gm-primary transition-colors">
                  
                  Najpredávanejšie
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-gm-text-muted hover:text-gm-primary transition-colors">
                  
                  Novinky
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-gm-text-muted hover:text-gm-primary transition-colors">
                  
                  Výhodné balenia
                </a>
              </li>
            </ul>
            <a
              href="#"
              className="inline-flex items-center mt-8 text-gm-primary font-medium hover:text-gm-primary-hover transition-colors">
              
              Zobraziť všetko <ArrowRight className="ml-2 w-4 h-4" />
            </a>
          </div>

          <div className="col-span-3 grid grid-cols-3 gap-6">
            {categories.map((category, idx) =>
            <div key={idx} className="group cursor-pointer">
                <div className="relative aspect-[4/3] rounded-gm-md overflow-hidden mb-4">
                  <img
                  src={category.image}
                  alt={category.title}
                  className="object-cover w-full h-full transition-transform duration-700 group-hover:scale-105" />
                
                  <div className="absolute inset-0 bg-black/10 group-hover:bg-black/0 transition-colors duration-300" />
                </div>
                <h4 className="font-heading text-lg mb-2">{category.title}</h4>
                <ul className="space-y-1">
                  {category.links.map((link, lIdx) =>
                <li key={lIdx}>
                      <span className="text-sm text-gm-text-muted group-hover:text-gm-text transition-colors">
                        {link}
                      </span>
                    </li>
                )}
                </ul>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>);

};