import React from 'react';
import { ProductCard } from '../commerce/ProductCard';
import { Filter, ChevronDown } from 'lucide-react';
export const CollectionPage = () => {
  const products = Array(8).
  fill(null).
  map((_, i) => ({
    title: `Premium Wellness Product ${i + 1}`,
    price: `€${(30 + i * 5).toFixed(2)}`,
    image: `https://images.unsplash.com/photo-${1600000000000 + i}?q=80&w=800&auto=format&fit=crop`,
    hoverImage: `https://images.unsplash.com/photo-${1610000000000 + i}?q=80&w=800&auto=format&fit=crop`,
    badge: i === 0 ? 'Best Seller' : i === 2 ? 'New' : undefined
  }));
  // Override with some real images for better preview
  products[0].image =
  'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?q=80&w=800&auto=format&fit=crop';
  products[0].hoverImage =
  'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?q=80&w=800&auto=format&fit=crop';
  products[1].image =
  'https://images.unsplash.com/photo-1608248543803-ba4f8c70ae0b?q=80&w=800&auto=format&fit=crop';
  products[2].image =
  'https://images.unsplash.com/photo-1629198688000-71f23e745b6e?q=80&w=800&auto=format&fit=crop';
  products[3].image =
  'https://images.unsplash.com/photo-1556228720-192a6af4e865?q=80&w=800&auto=format&fit=crop';
  products[4].image =
  'https://images.unsplash.com/photo-1617897903246-719242758050?q=80&w=800&auto=format&fit=crop';
  products[5].image =
  'https://images.unsplash.com/photo-1550831107-1553da8c8464?q=80&w=800&auto=format&fit=crop';
  products[6].image =
  'https://images.unsplash.com/photo-1570194065650-d6a2b8e30f14?q=80&w=800&auto=format&fit=crop';
  products[7].image =
  'https://images.unsplash.com/photo-1515377905703-c4788e51af15?q=80&w=800&auto=format&fit=crop';
  return (
    <div className="pt-32 pb-24">
      {/* Collection Hero */}
      <div className="gm-container mb-12 text-center max-w-3xl mx-auto">
        <h1 className="text-4xl md:text-5xl font-heading text-gm-text mb-4">
          Prémiové doplnky výživy
        </h1>
        <p className="text-gm-text-muted text-lg font-light">
          Objavte naša starostlivo vybranú kolekciu doplnkov výživy, formulovanú
          s prírodnými ingredienciami pre podporu vášho zdravia.
        </p>
      </div>

      {/* Toolbar */}
      <div className="sticky top-[80px] z-40 bg-gm-bg/90 backdrop-blur-md border-y border-gm-border py-4 mb-12">
        <div className="gm-container flex items-center justify-between">
          <button className="flex items-center text-sm font-medium text-gm-text hover:text-gm-primary transition-colors">
            <Filter className="w-4 h-4 mr-2" /> Filtrovať
          </button>

          <div className="text-sm text-gm-text-muted hidden md:block">
            Zobrazených 8 produktov
          </div>

          <button className="flex items-center text-sm font-medium text-gm-text hover:text-gm-primary transition-colors">
            Zoradiť podľa: Odporúčané <ChevronDown className="w-4 h-4 ml-1" />
          </button>
        </div>
      </div>

      {/* Active Filters */}
      <div className="gm-container mb-8 flex gap-2">
        <span className="inline-flex items-center px-3 py-1 rounded-full bg-gm-bg-soft text-xs text-gm-text">
          Skladom{' '}
          <button className="ml-2 hover:text-gm-primary">
            <X className="w-3 h-3" />
          </button>
        </span>
      </div>

      {/* Product Grid */}
      <div className="gm-container">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-6 gap-y-12">
          {products.map((product, idx) =>
          <ProductCard key={idx} {...product} />
          )}
        </div>
      </div>
    </div>);

};
// Helper for X icon since it wasn't imported at the top
const X = ({ className }: {className?: string;}) =>
<svg
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  strokeWidth="2"
  strokeLinecap="round"
  strokeLinejoin="round"
  className={className}>
  
    <path d="M18 6 6 18" />
    <path d="m6 6 12 12" />
  </svg>;