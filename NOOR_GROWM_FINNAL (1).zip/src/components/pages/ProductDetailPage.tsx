import React, { useState } from 'react';
import { LiquidButton } from '../ui/LiquidButton';
import {
  Minus,
  Plus,
  Star,
  Truck,
  ShieldCheck,
  ChevronDown } from
'lucide-react';
import { clsx } from 'clsx';
export const ProductDetailPage = () => {
  const [quantity, setQuantity] = useState(1);
  const [activeTab, setActiveTab] = useState('ingredients');
  return (
    <div className="pt-32 pb-24">
      <div className="gm-container">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 lg:gap-24">
          {/* Left: Image Gallery */}
          <div className="space-y-4">
            <div className="aspect-[4/5] bg-gm-bg-soft rounded-gm-lg overflow-hidden sticky top-[100px]">
              <img
                src="https://images.unsplash.com/photo-1620916566398-39f1143ab7be?q=80&w=1000&auto=format&fit=crop"
                alt="HydraSilk Skin Reviving Cleanser"
                className="w-full h-full object-cover" />
              
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="aspect-square bg-gm-bg-soft rounded-gm-md overflow-hidden">
                <img
                  src="https://images.unsplash.com/photo-1556228578-0d85b1a4d571?q=80&w=500&auto=format&fit=crop"
                  alt="Detail 1"
                  className="w-full h-full object-cover" />
                
              </div>
              <div className="aspect-square bg-gm-bg-soft rounded-gm-md overflow-hidden">
                <img
                  src="https://images.unsplash.com/photo-1617897903246-719242758050?q=80&w=500&auto=format&fit=crop"
                  alt="Detail 2"
                  className="w-full h-full object-cover" />
                
              </div>
            </div>
          </div>

          {/* Right: Product Info */}
          <div className="flex flex-col">
            <div className="sticky top-[100px]">
              {/* Breadcrumbs */}
              <nav className="text-xs text-gm-text-muted mb-6 flex items-center space-x-2">
                <a href="#" className="hover:text-gm-text">
                  Domov
                </a>
                <span>/</span>
                <a href="#" className="hover:text-gm-text">
                  Kategórie
                </a>
                <span>/</span>
                <span className="text-gm-text">Vitamíny</span>
              </nav>

              <h1 className="text-3xl md:text-4xl font-heading text-gm-text mb-2">
                Lipozomálny Vitamín C
              </h1>

              <div className="flex items-center space-x-4 mb-6">
                <span className="text-2xl font-medium text-gm-text">
                  64,95 €
                </span>
                <div className="flex items-center text-gm-primary">
                  <Star className="w-4 h-4 fill-current" />
                  <Star className="w-4 h-4 fill-current" />
                  <Star className="w-4 h-4 fill-current" />
                  <Star className="w-4 h-4 fill-current" />
                  <Star className="w-4 h-4 fill-current opacity-50" />
                  <span className="text-sm text-gm-text-muted ml-2">
                    (128 recenzií)
                  </span>
                </div>
              </div>

              <p className="text-gm-text-muted font-light leading-relaxed mb-8">
                Vysoko vstrebateľný lipozomálny vitamín C pre maximálnu podporu
                imunitného systému. Vďaka lipozomálnej technológii sa vitamín C
                dostáva priamo do buniek bez podráždenia žalúdka.
              </p>

              {/* Variant Selector Placeholder */}
              <div className="mb-8">
                <h3 className="text-sm font-medium text-gm-text mb-3">
                  Balenie
                </h3>
                <div className="flex space-x-3">
                  <button className="border-2 border-gm-text text-gm-text px-4 py-2 rounded-gm-sm text-sm font-medium">
                    60 kapsúl
                  </button>
                  <button className="border border-gm-border text-gm-text-muted px-4 py-2 rounded-gm-sm text-sm hover:border-gm-text transition-colors">
                    120 kapsúl
                  </button>
                </div>
              </div>

              {/* Add to Cart Block */}
              <div className="flex space-x-4 mb-8">
                <div className="flex items-center border border-gm-border rounded-gm-md px-4 py-3 bg-white">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="text-gm-text-muted hover:text-gm-text">
                    
                    <Minus className="w-4 h-4" />
                  </button>
                  <span className="w-12 text-center font-medium">
                    {quantity}
                  </span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="text-gm-text-muted hover:text-gm-text">
                    
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
                <LiquidButton className="flex-1 text-lg">
                  Do košíka
                </LiquidButton>
              </div>

              {/* Trust Badges */}
              <div className="grid grid-cols-2 gap-4 py-6 border-y border-gm-border mb-8">
                <div className="flex items-center text-sm text-gm-text">
                  <Truck className="w-5 h-5 mr-3 text-gm-primary" />
                  <span>Doprava zadarmo nad 50 €</span>
                </div>
                <div className="flex items-center text-sm text-gm-text">
                  <ShieldCheck className="w-5 h-5 mr-3 text-gm-primary" />
                  <span>100% Prírodné zloženie</span>
                </div>
              </div>

              {/* Accordion Tabs */}
              <div className="space-y-4">
                {['zloženie', 'dávkovanie', 'doprava'].map((tab) =>
                <div key={tab} className="border-b border-gm-border pb-4">
                    <button
                    className="flex justify-between items-center w-full text-left uppercase tracking-wider text-sm font-medium text-gm-text"
                    onClick={() => setActiveTab(activeTab === tab ? '' : tab)}>
                    
                      {tab}
                      <ChevronDown
                      className={clsx(
                        'w-4 h-4 transition-transform',
                        activeTab === tab && 'rotate-180'
                      )} />
                    
                    </button>
                    {activeTab === tab &&
                  <div className="mt-4 text-sm text-gm-text-muted font-light leading-relaxed animate-fade-in">
                        {tab === 'zloženie' &&
                    'Vitamín C (kyselina L-askorbová), slnečnicový lecitín (zdroj lipozómov), vegánska kapsula (hydroxypropylmetylcelulóza). Bez lepku, laktózy a umelých farbív.'}
                        {tab === 'dávkovanie' &&
                    'Užívajte 1-2 kapsuly denne, ideálne ráno nalačno alebo s jedlom. Zapiť dostatočným množstvom vody.'}
                        {tab === 'doprava' &&
                    'Štandardné doručenie trvá 1-2 pracovné dni. Možnosť expresného doručenia. 30-dňová garancia vrátenia peňazí na neotvorené produkty.'}
                      </div>
                  }
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>);

};