
# Logo

GrowMedica brandmark — Playfair Display wordmark with an optional peach leaf glyph. Links to home.

## Props

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `showIcon` | `boolean` | `true` | Toggle the leaf glyph. |
| `className` | `string` | — | Extra classes. |

## Usage

```tsx
import { Logo } from 'components/Logo'

<Logo />
```
