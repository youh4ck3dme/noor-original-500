

# Spinner

Peach-tinted loading spinner. Respects `prefers-reduced-motion`.

## Props

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `size` | `'sm' \| 'md' \| 'lg'` | `'md'` | Spinner size. |
| `label` | `string` | `'Načítava sa…'` | Accessible label. |
| `className` | `string` | — | Extra classes. |

## Usage

```tsx
import { Spinner } from 'components/Spinner'

<Spinner size="lg" />
```

